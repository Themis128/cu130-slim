# Meta Support Report Package

This package contains everything needed to submit a "Report a Problem" to
Facebook about the account restriction blocking business verification.

## Contents

- `template/report-description.txt` — The report description text (paste into the form)
- `template/SCREENSHOTS.md` — Manifest of all screenshots with descriptions
- `screenshots/` — All captured screenshots (14 PNG files)

## How to submit

1. Go to https://www.facebook.com/
2. Click profile picture (top right) > Help & support > Report a problem
3. Click "Include" (to include logs and diagnostics)
4. Paste the contents of `template/report-description.txt` into the textarea
5. Click "Capture Screen" and select a screen area (required — native browser dialog)
6. Attach screenshots from the `screenshots/` folder (recommended: 01, 06, 09)
7. Click "Submit report"

## Key identifiers

- App ID: 1936126137016578
- App name: Cloudless
- Business portfolio: cloudless.gr (ID: 1558125105019725)
- Ad account: 657781691826702 (disabled Jan 24, 2021)
